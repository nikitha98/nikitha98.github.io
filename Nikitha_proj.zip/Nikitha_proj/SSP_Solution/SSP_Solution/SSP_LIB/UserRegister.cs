﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
namespace SSP_LIB
{
    /*create Procedure Insert_Login_Page @UserID varchar(15),@UserPassword varchar(15)*/
   
    /*create Procedure Insert_Personal_details @UserId varchar(50),@First_Name varchar(50) ,@Last_Name varchar(50) ,@Date_Of_Birth datetime ,@Age int,@Gender char(6) ,
@Contact_no char(10) ,@Father_Name varchar(50),@Mothers_Name varchar(50) ,@Income_Details varchar(50)  */

    public class UserRegister
    {
        public static int RegisterUserInfo(SqlConnection con, string uid, string password, string utype, string First_Name, string Last_Name, DateTime Date_Of_Birth, int Age, string Gender, string Contact_no, string Father_Name, string Mother_Name, string Income_Details,
            string SSLCBoard, string SSLCSchool, string SSLCCity, string SSLCState, string HSCBoard, string HSCSchool, string HSCCity, string HSCState, string Graduation, string GraduationCollege, string GraduationCity, string GraduationState,
            string Street, string Locality, string City, string AddressState, string ZipCode, string Caste, byte[] uploadfile, string AccountNo, string BankName, string IFSCCode, String BankCity,int m10,int m12)
        {
            int r = 0;
            try
            {
                
                if (InsertLoginDetails(con, uid, password,utype) > 0)
                {
                    if (InsertUserDetails(con, uid,First_Name, Last_Name, Date_Of_Birth, Age, Gender, Contact_no, Father_Name, Mother_Name, Income_Details) > 0)
                    {
                        if (InsertEducationalDetails(con, uid, SSLCBoard, SSLCSchool, SSLCCity, SSLCState, HSCBoard, HSCSchool, HSCCity, HSCState, Graduation, GraduationCollege, GraduationCity, GraduationState,m10,m12) > 0)
                        {
                            if (InsertAddressDetails(con, uid, Street, Locality, City, AddressState, ZipCode) > 0)
                            {
                                if (InsertCasteDetails(con, uid, Caste, uploadfile) > 0)
                                {
                                    if (InsertBankDetails(con, uid, AccountNo, BankName, IFSCCode, BankCity) > 0)
                                    {
                                        r = 1;
                                    }
                                    else
                                    {
                                        r = 0;
                                    }
                                }
                                else
                                {
                                    r = 0;
                                }
                            }
                            else
                            {
                                r = 0;
                            }
                        }
                        else
                        {
                            r = 0;
                        }
                    }
                    else
                    {
                        r = 0;
                    }
                }
                else
                {
                    r = 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return r;
        }
        public static int EditPersonalStatus(SqlConnection con, string uid, string First_Name, string Last_Name, DateTime Date_Of_Birth, int Age, string Gender, string Contact_no, string Father_Name, string Mother_Name, string Income_Details)
        {
            int r = 0;
            try
            {
               
                    if (EditUserDetails(con, uid,First_Name, Last_Name, Date_Of_Birth, Age, Gender, Contact_no, Father_Name, Mother_Name, Income_Details) > 0)
                    {
                             r = 1;
                    }
                       else
                    {
                            r = 0;
                     }
              }
          
            
            catch (Exception ex)
            {
                throw ex;
            }
            return r;
        }
        public static int EditEducationStatus(SqlConnection con,string uid, string SSLCBoard, string SSLCSchool, string SSLCCity, string SSLCState, string HSCBoard, string HSCSchool, string HSCCity, string HSCState, string Graduation, string GraduationCollege, string GraduationCity, string GraduationState)
                {
                    int r = 0;
                    try
                    {
                        if (EditEducationalDetails(con, uid, SSLCBoard, SSLCSchool, SSLCCity, SSLCState, HSCBoard, HSCSchool, HSCCity, HSCState, Graduation, GraduationCollege, GraduationCity, GraduationState) > 0)
                        {
                            r = 1;
                        }
                        else
                        {
                            r = 0;
                        }
                    }

                    catch (Exception ex)
                    {
                        throw ex;
                    }
            return r;
        }


         public static int EditCasteStatus(SqlConnection con, string uid,string Caste, byte[] uploadfile)
        {
            int r = 0;
            try
            {
                                if (EditCasteDetails(con, uid, Caste, uploadfile) > 0)
                                    {
                                        r = 1;
                                    }
                                    else
                                    {
                                        r = 0;
                                    }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return r;
        }

        public static int EditBankStatus(SqlConnection con, string uid, string AccountNo, string BankName, string IFSCCode, String BankCity)
        {
            int r = 0;
            try
            {
                                 if (EditBankDetails(con, uid, AccountNo, BankName, IFSCCode, BankCity) > 0)
                                    {
                                        r = 1;
                                    }
                                    else
                                    {
                                        r = 0;
                                    }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return r;
        }
       
        

        public static int InsertLoginDetails(SqlConnection con, string uid, string password,string utype)
        {
            SqlCommand cmd = new SqlCommand("Insert_Login_Page", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@Password", password);
            cmd.Parameters.AddWithValue("@utype", utype);
            return cmd.ExecuteNonQuery();
        }
      
        public static int InsertUserDetails(SqlConnection con,string uid,string First_Name, string Last_Name, DateTime Date_Of_Birth, int Age, string Gender, string Contact_no, string Father_Name, string Mother_Name, string Income_Details)
        {
            SqlCommand cmd = new SqlCommand("Insert_Personal_details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@First_Name", First_Name);
            cmd.Parameters.AddWithValue("@Last_Name", Last_Name);
            cmd.Parameters.AddWithValue("@Date_Of_Birth", Date_Of_Birth);
            cmd.Parameters.AddWithValue("@Age", Age);
            cmd.Parameters.AddWithValue("@Gender", Gender);
            cmd.Parameters.AddWithValue("@Contact_no", Contact_no);
            cmd.Parameters.AddWithValue("@Father_Name", Father_Name);
            cmd.Parameters.AddWithValue("@Mothers_Name", Mother_Name);
            cmd.Parameters.AddWithValue("@Income_Details", Income_Details);
            cmd.Parameters.AddWithValue("@ApplicationStatus", "APPLIED");
            cmd.Parameters.AddWithValue("@Remarks", "");
            return cmd.ExecuteNonQuery();
        }

        /*
         create Procedure Insert_Education_Details @UserId varchar(50) ,@SSLCBoard varchar(50) ,@SSLCSchool varchar(50) ,@SSLCCity varchar(50),@SSLCState varchar(50),
@HSCBoard varchar(50) ,@HSCSchool varchar(50),@HSCCity varchar(50) ,@HSCState varchar(50) ,@Graduation varchar(50),@GraduationCollege varchar(50),@GraduationCity varchar(50) ,
@GraduationState varchar(50) @Marks_10, @Marks_12
         */
        public static int InsertEducationalDetails(SqlConnection con, String uid, string SSLCBoard,string SSLCSchool, string SSLCCity,string SSLCState,string HSCBoard,string HSCSchool,string HSCCity,string HSCState,string Graduation,string GraduationCollege, string GraduationCity,string GraduationState,int m10, int m12)
        {
            SqlCommand cmd = new SqlCommand("Insert_Education_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@SSLCBoard", SSLCBoard);
            cmd.Parameters.AddWithValue("@SSLCSchool", SSLCSchool);
            cmd.Parameters.AddWithValue("@SSLCCity", SSLCCity);
            cmd.Parameters.AddWithValue("@SSLCState", SSLCState);
            cmd.Parameters.AddWithValue("@HSCBoard", HSCBoard);
            cmd.Parameters.AddWithValue("@HSCSchool", HSCSchool);
            cmd.Parameters.AddWithValue("@HSCCity", HSCCity);
            cmd.Parameters.AddWithValue("@HSCState", HSCState);
            cmd.Parameters.AddWithValue("@Graduation", Graduation);
            cmd.Parameters.AddWithValue("@GraduationCollege", GraduationCollege);
            cmd.Parameters.AddWithValue("@GraduationCity",GraduationCity);
            cmd.Parameters.AddWithValue("@GraduationState", GraduationState);
            cmd.Parameters.AddWithValue("@Marks_10", m10);
            cmd.Parameters.AddWithValue("@Marks_12", m12);
            return cmd.ExecuteNonQuery();
        }

        /*create Procedure Insert_Address_Details @UserId varchar(50) ,@Street varchar(50),@Locality varchar(50),@City varchar(50),@AddressState varchar(50),@ZipCode char(10)*/

        public static int InsertAddressDetails(SqlConnection con, String uid, string Street, string Locality, string City, string AddressState, string ZipCode)
        {
            SqlCommand cmd = new SqlCommand("Insert_Address_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@Street", Street);
            cmd.Parameters.AddWithValue("@Locality", Locality);
            cmd.Parameters.AddWithValue("@City", City);
            cmd.Parameters.AddWithValue("@AddressState", AddressState);
            cmd.Parameters.AddWithValue("@ZipCode", ZipCode);           
            return cmd.ExecuteNonQuery();
        } 

       /* create Procedure Insert_Caste_Details @UserId varchar(50) ,@Caste varchar(30) ,@uploadfile varchar(50)*/

        public static int InsertCasteDetails(SqlConnection con, String uid, string Caste, byte[] uploadfile)
        {
            SqlCommand cmd = new SqlCommand("Insert_Caste_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@Caste", Caste);
            cmd.Parameters.AddWithValue("@uploadfile", uploadfile);
            return cmd.ExecuteNonQuery();
        } 

        /*create Procedure Insert_Bank_Details @UserId varchar(50),@AccountNo varchar(50) ,@BankName varchar(50) ,@IFSCCode varchar(50),@City varchar(50)*/

        public static int InsertBankDetails(SqlConnection con, String uid, string AccountNo, string BankName, string IFSCCode, string BankCity)
        {
            SqlCommand cmd = new SqlCommand("Insert_Bank_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@AccountNo", AccountNo);
            cmd.Parameters.AddWithValue("@BankName", BankName);
            cmd.Parameters.AddWithValue("@IFSCCode", IFSCCode);
            cmd.Parameters.AddWithValue("@City", BankCity);
            return cmd.ExecuteNonQuery();
        }


        public static SqlDataReader GetAllPersonalDetails(SqlConnection con, string uid)
        {
           
            SqlCommand cmd = new SqlCommand("Find_Personal_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", uid);
            return cmd.ExecuteReader();
        }

        public static SqlDataReader GetAllEducationDetails(SqlConnection con, string uid)
        {
           
            SqlCommand cmd = new SqlCommand("Find_Education_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", uid);
            return cmd.ExecuteReader();
        }
        public static SqlDataReader GetAllAddressDetails(SqlConnection con, string uid)
        {
          
            SqlCommand cmd = new SqlCommand("Find_Address_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", uid);
            return cmd.ExecuteReader();
        }

        public static SqlDataReader GetAllCasteDetails(SqlConnection con, string uid)
        {
           
            SqlCommand cmd = new SqlCommand("Find_Caste_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", uid);
            return cmd.ExecuteReader();
        }

        public static SqlDataReader GetAllBankDetails(SqlConnection con, string uid)
        {
         
            SqlCommand cmd = new SqlCommand("Find_Bank_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", uid);
            return cmd.ExecuteReader();
        }


        public static int EditUserDetails(SqlConnection con, string uid, string First_Name, string Last_Name, DateTime Date_Of_Birth, int Age, string Gender, string Contact_no, string Father_Name, string Mother_Name, string Income_Details)
        {
            SqlCommand cmd = new SqlCommand("Edit_Personal_details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@First_Name", First_Name);
            cmd.Parameters.AddWithValue("@Last_Name", Last_Name);
            cmd.Parameters.AddWithValue("@Date_Of_Birth", Date_Of_Birth);
            cmd.Parameters.AddWithValue("@Age", Age);
            cmd.Parameters.AddWithValue("@Gender", Gender);
            cmd.Parameters.AddWithValue("@Contact_no", Contact_no);
            cmd.Parameters.AddWithValue("@Father_Name", Father_Name);
            cmd.Parameters.AddWithValue("@Mothers_Name", Mother_Name);
            cmd.Parameters.AddWithValue("@Income_Details", Income_Details);
            return cmd.ExecuteNonQuery();
        }

        public static int EditEducationalDetails(SqlConnection con, String uid, string SSLCBoard, string SSLCSchool, string SSLCCity, string SSLCState, string HSCBoard, string HSCSchool, string HSCCity, string HSCState, string Graduation, string GraduationCollege, string GraduationCity, string GraduationState)
        {
            SqlCommand cmd = new SqlCommand("Edit_Education_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@SSLCBoard", SSLCBoard);
            cmd.Parameters.AddWithValue("@SSLCSchool", SSLCSchool);
            cmd.Parameters.AddWithValue("@SSLCCity", SSLCCity);
            cmd.Parameters.AddWithValue("@SSLCState", SSLCState);
            cmd.Parameters.AddWithValue("@HSCBoard", HSCBoard);
            cmd.Parameters.AddWithValue("@HSCSchool", HSCSchool);
            cmd.Parameters.AddWithValue("@HSCCity", HSCCity);
            cmd.Parameters.AddWithValue("@HSCState", HSCState);
            cmd.Parameters.AddWithValue("@Graduation", Graduation);
            cmd.Parameters.AddWithValue("@GraduationCollege", GraduationCollege);
            cmd.Parameters.AddWithValue("@GraduationCity", GraduationCity);
            cmd.Parameters.AddWithValue("@GraduationState", GraduationState);
            return cmd.ExecuteNonQuery();
        }


        public static int EditAddressDetails(SqlConnection con, String uid, string Street, string Locality, string City, string AddressState, string ZipCode)
        {
            SqlCommand cmd = new SqlCommand("Edit_Address_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@Street", Street);
            cmd.Parameters.AddWithValue("@Locality", Locality);
            cmd.Parameters.AddWithValue("@City", City);
            cmd.Parameters.AddWithValue("@AddressState", AddressState);
            cmd.Parameters.AddWithValue("@ZipCode", ZipCode);
            return cmd.ExecuteNonQuery();
        }


        public static int EditCasteDetails(SqlConnection con, String uid, string Caste, byte[] uploadfile)
        {
            SqlCommand cmd = new SqlCommand("Edit_Caste_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@Caste", Caste);
            cmd.Parameters.AddWithValue("@uploadfile", uploadfile);
            return cmd.ExecuteNonQuery();
        } 


        public static int EditBankDetails(SqlConnection con, String uid, string AccountNo, string BankName, string IFSCCode, string BankCity)
        {
            SqlCommand cmd = new SqlCommand("Edit_Bank_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@AccountNo", AccountNo);
            cmd.Parameters.AddWithValue("@BankName", BankName);
            cmd.Parameters.AddWithValue("@IFSCCode", IFSCCode);
            cmd.Parameters.AddWithValue("@City", BankCity);
            return cmd.ExecuteNonQuery();
        } 
    }
}
