﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace SSP_LIB
{
    public class DBConnector
    {
        public static SqlConnection GetDBConnection()
        {
            SqlConnection con = new SqlConnection("Data Source=(localdb)\\Projects;Initial Catalog=master;Integrated Security=True;");
            con.Open();
            return con;
        }
        /*create procedure ValidateUserLogin @UserId varchar(50), @userpassord varchar(15),@status varchar(10) out*/

        public static String ValidateUserLogin(SqlConnection con, string userid, string psw,string utype)
        {
            string status = "";

            SqlCommand cmd = new SqlCommand("ValidateUserLogin",con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId",userid);
            cmd.Parameters.AddWithValue("@userpassword", psw);
            cmd.Parameters.AddWithValue("@utype", utype.Substring(0,1));
            SqlParameter spl = new SqlParameter();
            spl.ParameterName = "@status";
            spl.SqlDbType = SqlDbType.VarChar;
            spl.Size = 10;
            spl.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(spl);

            cmd.ExecuteReader();
            status=(string)spl.Value;
            return status;
        }

    }
}
