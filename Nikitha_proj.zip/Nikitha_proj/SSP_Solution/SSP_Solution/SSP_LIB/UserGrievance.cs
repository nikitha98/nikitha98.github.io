﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace SSP_LIB
{
    public class UserGrievance
    {
        public static int InsertUserGrievance(SqlConnection con, string uid, string First_Name, string Last_Name, DateTime PostDate, string Grievance_Subject, string Grievance_Description)
        {
            SqlCommand cmd = new SqlCommand("Add_User_Grievances", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", uid);
            cmd.Parameters.AddWithValue("@FirstName", First_Name);
            cmd.Parameters.AddWithValue("@LastName", Last_Name);
            cmd.Parameters.AddWithValue("@PostDate", PostDate);
            cmd.Parameters.AddWithValue("@Grievance_Subject", Grievance_Subject);
            cmd.Parameters.AddWithValue("@Grievance_Description", Grievance_Description);
            return cmd.ExecuteNonQuery();
        }

        public static SqlDataReader GetUserGrievance(SqlConnection con, string uid)
        {
            SqlCommand cmd = new SqlCommand("CheckGrievanceDetails_ByUserId", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userid", uid);
            return cmd.ExecuteReader();
        }

        public static int EditUserGrievance(SqlConnection con, string uid, string ReplyingAdminId, string ReplyingMessage)
        {
            SqlCommand cmd = new SqlCommand("ReplyGrievanceDetails_ByUserId", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", uid);
            cmd.Parameters.AddWithValue("@ReplyingAdminId ", ReplyingAdminId);
            cmd.Parameters.AddWithValue("@ReplyingMessage", ReplyingMessage);
            return cmd.ExecuteNonQuery();
        }
        public static int Remove_userDetails(SqlConnection con, string uid)
        {
            SqlCommand cmd = new SqlCommand("Remove_user", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", uid);
            return cmd.ExecuteNonQuery();
        }
    

    }
}

/*UserId varchar(50) primary key not null,
FirstName varchar(50) not null,
LastName varchar(50) not null,
PostDate datetime default GetDate(),
Grievance_Subject varchar(100) not null,
Grievance_Description varchar(400) not null,
 * @UserId,@FirstName,@LastName,@PostDate,@Grievance_Subject,@Grievance_Description
 @UserId varchar(50),@ReplyingAdminId varchar(50), @ReplyingMessage  varchar(400)*/