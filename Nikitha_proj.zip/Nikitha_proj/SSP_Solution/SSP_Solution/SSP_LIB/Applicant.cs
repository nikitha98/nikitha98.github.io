﻿using System;
using System.Data;
using System.Data.SqlClient;


namespace SSP_LIB
{
    public class Applicant
    {
        public static SqlDataReader GetAllRejectedUserIdNames(SqlConnection con)
        {
            return (new SqlCommand("select userid, first_name, last_name from Personal_details where userid IN (select userid from Login_Page where not usertype = 'A') and (ApplicationStatus = 'REJECTED' OR ApplicationStatus = 'STRICTLY REJECTED')", con)).ExecuteReader();
        }
        public static SqlDataReader GetRejectedUserIdNames(SqlConnection con)
        {
            return (new SqlCommand("select userid, first_name, last_name from Personal_details where userid IN (select userid from Login_Page where not usertype = 'A') and ApplicationStatus = 'REJECTED'", con)).ExecuteReader();
        }
        public static SqlDataReader GetShortListUserIdNames(SqlConnection con)
        {
            return (new SqlCommand("select userid, first_name, last_name from Personal_details where userid IN (select userid from Login_Page where not usertype = 'A') and ApplicationStatus = 'ACCEPTED'", con)).ExecuteReader();
        }
        public static SqlDataReader GetUserIdNames(SqlConnection con)
        {
            return (new SqlCommand("select userid, first_name, last_name from Personal_details where userid IN (select userid from Login_Page where not usertype = 'A') and ApplicationStatus = 'APPLIED'", con)).ExecuteReader();
        }

        public static SqlDataReader GetUserIdNames(SqlConnection con,String UserId)
        {
            return (new SqlCommand("select userid, first_name, last_name from Personal_details where userid ='"+UserId+"'", con)).ExecuteReader();
        }

        public static DataSet GetPersonalDetails(SqlConnection con, String userid)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Personal_details where UserId='" + userid + "'", con);
            sda.Fill(ds, "Personal_details");
            return ds;
        }
        public static DataSet GetEducationDetails(SqlConnection con, String userid)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Education_Details where UserId='" + userid + "'", con);
            sda.Fill(ds, "Education_Details");
            return ds;
        }

        public static SqlDataReader GetPersonalDetailsonGrievance(SqlConnection con, String userid)
        {
           
             return (new SqlCommand("Select Income_Details from Personal_details where UserId='" + userid + "'", con)).ExecuteReader();
            
        }
        public static SqlDataReader GetEducationDetailsonGrievance(SqlConnection con, String userid)
        {

            return (new SqlCommand("Select Marks_10, Marks_12 from Education_Details where UserId='" + userid + "'", con)).ExecuteReader();
          
        }

        public static DataSet GetAddressDetails(SqlConnection con, String userid)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Address_Details where UserId='" + userid + "'", con);
            sda.Fill(ds, "Address_Details");
            return ds;
        }
        public static DataSet GetBankDetails(SqlConnection con, String userid)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * from Bank_Details where UserId='" + userid + "'", con);
            sda.Fill(ds, "Bank_Details");
            return ds;
        }
        public static SqlDataReader GetCasteDetails(SqlConnection con, string uid)
        {

            SqlCommand cmd = new SqlCommand("Find_Caste_Details", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", uid);
            return cmd.ExecuteReader();
        }

        //UPDATEAPPLICATIONSTATUS  @appstatus varchar(20), @remarks varchar(100), @userid varchar(50)

        public static int UpdateApplicationStatus(SqlConnection con, string uid, string appstatus, string remarks)
        {
            SqlCommand cmd = new SqlCommand("UPDATEAPPLICATIONSTATUS", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@appstatus", appstatus);
            cmd.Parameters.AddWithValue("@remarks", remarks);
            cmd.Parameters.AddWithValue("@userId", uid);
            return cmd.ExecuteNonQuery();
        }

    }
}
