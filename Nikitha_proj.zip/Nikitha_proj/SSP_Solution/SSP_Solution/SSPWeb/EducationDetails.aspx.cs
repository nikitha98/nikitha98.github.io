﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class EducationDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string userid = (string)Session["USERID"];
                lbWelcome1.Text = "Welcome " + userid + " || Accessed Time : " + DateTime.Now;

                SqlDataReader sdr = UserTask.GetEducationDetails(userid);
                if (sdr.Read())
                {
                    lbUserId.Text = sdr[0].ToString();
                    lb10Board.Text = sdr[1].ToString();
                    lb10School.Text = sdr[2].ToString();
                    lb10City.Text = sdr[3].ToString();
                    lb10State.Text = sdr[4].ToString();
                    lb12Board.Text = sdr[5].ToString();
                    lb12School.Text = sdr[6].ToString();
                    lb12City.Text = sdr[7].ToString();
                    lb12State.Text = sdr[8].ToString();
                    lbGrBoard.Text = sdr[9].ToString();
                    lbGrClg.Text = sdr[10].ToString();
                    lbGrCity.Text = sdr[11].ToString();
                    lbGrState.Text = sdr[12].ToString();
                    lbMark_10.Text = sdr[13].ToString();
                    lbMark_12.Text = sdr[14].ToString();

                }
            }


        }

        //protected void EducationalDetails1_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("EducationDetails.aspx");
        //}

        

        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }

    }
}