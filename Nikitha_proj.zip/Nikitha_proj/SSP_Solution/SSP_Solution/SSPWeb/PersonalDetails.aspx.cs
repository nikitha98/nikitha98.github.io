﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class PersonalDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string uid = (string)Session["USERID"];
                lbWelcome.Text = "Welcome " + uid + " || Accessed Time : " + DateTime.Now;

                SqlDataReader sdr = UserTask.GetPersonalDetails(uid);
                if (sdr.Read())
                {
                    lbUserId.Text = sdr[0].ToString();
                    lbFN.Text = sdr[1].ToString();
                    lbLN.Text = sdr[2].ToString();
                    lbDOB.Text = sdr[3].ToString();
                    lbAge.Text = sdr[4].ToString();
                    lbGender.Text = sdr[5].ToString();
                    lbContactNo.Text = sdr[6].ToString();
                    lbFatherName.Text = sdr[7].ToString();
                    lbMotherName.Text = sdr[8].ToString();
                    lbIncome.Text = sdr[9].ToString();
                }
            }

        }

 
        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }

    }
}