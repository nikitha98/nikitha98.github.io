﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class AddressDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string userid = (string)Session["USERID"];
                lbWelcome3.Text = "Welcome " + userid + " || Accessed Time : " + DateTime.Now;

                SqlDataReader sdr = UserTask.GetAddressDetails(userid);
                if (sdr.Read())
                {
                    lbUserId.Text = sdr[0].ToString();
                    lbStreet.Text = sdr[1].ToString();
                    lbLocality.Text = sdr[2].ToString();
                    lbCity.Text = sdr[3].ToString();
                    lbState.Text = sdr[4].ToString();
                    lbZip.Text = sdr[5].ToString();

                }
            }
        }

        protected void AddressTable_SelectedIndexChanged(object sender, EventArgs e)
        {
            Response.Redirect("AddressDetails.aspx");
        }


      

        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }

        protected void EducationEdit_Click(object sender, EventArgs e)
        {

        }

       
    }
}