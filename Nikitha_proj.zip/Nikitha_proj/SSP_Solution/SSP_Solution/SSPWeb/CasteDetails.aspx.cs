﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class CasteDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String userid = (String)Session["Userid"];
            lbUserid1.Text = "Welcome " + userid + " || Accessed Time : " + DateTime.Now;
            if (!IsPostBack)
            {
                SqlDataReader sdr=UserTask.GetCasteDetails(userid);
                if (sdr.Read())
                {
                    lbUserId.Text = sdr[0].ToString();
                    lbCaste.Text = sdr[1].ToString();
                    byte[] imgbytes = (byte[])sdr[2];
                    string imagesbytes=Convert.ToBase64String(imgbytes);
                    imgCaste.ImageUrl = String.Format(@"data:image/jpg;base64,{0}",imagesbytes);
                }
                sdr.Close();
            }
        }

       

        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }
    }
}