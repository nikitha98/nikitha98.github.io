﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class ProfileApplications : System.Web.UI.Page
    {
        string applicationstatus = "";
        string remarks = "";
        string Gender = "";
        int Marks_10th = 0;
        int Marks_12th = 0;
        int family_income = 0;
        string uid = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            uid= (string)Session["Userid"];
            lbWelcome.Text = "Welcome " + uid + ", Page Accessed Time :" + DateTime.Now;
            if (!Page.IsPostBack)
            {
                lbStatus.Text = "";
                btnAccept.Enabled = false;
                panel1.Visible = true;
                panel2.Visible = false;
                SqlDataReader sdr=AdminTask.GetUserIdNames();
                while (sdr.Read())
                {
                    String ddlItem = sdr[0] + "-" + sdr[1] + "_" + sdr[2];
                    ddlStudentList.Items.Add(ddlItem);
                }
                sdr.Close();
                ddlStudentList.SelectedIndex = 0;
            }
        }

        protected void Profile_out_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("USERID");
        }

        protected void linkHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("ProfileAdmin.aspx");
        }

        protected void ddlStudentList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStudentList.SelectedIndex == 0)
            {
                panel2.Visible = false;
            }
            else
            {
                panel2.Visible = true;
                string userid = ddlStudentList.SelectedValue.Substring(0, ddlStudentList.SelectedValue.IndexOf("-"));
                Session.Add("App_User", userid);
                DataSet ds1 = Student.GetPersonalDetails(userid);
                GVPD.DataSource = ds1;
                Gender = (string)ds1.Tables[0].Rows[0][ds1.Tables[0].Columns[5]];
              
                Session.Add("Gnd", Gender);
                family_income = Int32.Parse((string)ds1.Tables[0].Rows[0][ds1.Tables[0].Columns[9]]);
                Session.Add("Fam_Income", family_income);
                GVPD.DataMember = ds1.Tables[0].TableName;
                GVPD.DataBind();

                DataSet ds2 = Student.GetEducationDetails(userid);
                GVED.DataSource = ds2;

                Marks_10th = (int)ds2.Tables[0].Rows[0][ds2.Tables[0].Columns[13]];
                Session.Add("M10", Marks_10th);
                Marks_12th = (int)ds2.Tables[0].Rows[0][ds2.Tables[0].Columns[14]];
                Session.Add("M12", Marks_12th);
                
                
                GVED.DataMember = ds2.Tables[0].TableName;
                GVED.DataBind();

                DataSet ds3 = Student.GetAddressDetails(userid);
                GVAD.DataSource = ds3;
                GVAD.DataMember = ds3.Tables[0].TableName;
                GVAD.DataBind();

                DataSet ds4 = Student.GetBankDetails(userid);
                GVBD.DataSource = ds4;
                GVBD.DataMember = ds4.Tables[0].TableName;
                GVBD.DataBind();

                SqlDataReader sdr = Student.GetAllCasteDetails(userid);
                if (sdr.Read())
                {
                    lbUserId.Text = sdr[0].ToString();
                    lbCaste.Text = sdr[1].ToString();
                    byte[] imgbytes = (byte[])sdr[2];
                    string imagesbytes = Convert.ToBase64String(imgbytes);
                    imgCaste.ImageUrl = String.Format(@"data:image/jpg;base64,{0}", imagesbytes);
                }
                sdr.Close();
            }
        }

        protected void chbAgree_CheckedChanged(object sender, EventArgs e)
        {
            if (chbAgree.Checked == true)
            {
                if (rb1.Checked == true || rb2.Checked == true)
                {
                    btnAccept.Enabled = true;
                    
                }
            }
            else
            {
                rb1.Checked = false;
                rb2.Checked = false;
                btnAccept.Enabled = false; ;
            }
        }

        protected void btnAccept_Click(object sender, EventArgs e)
        {
            String app_uid = (string)Session["App_User"];
            if (chbAgree.Checked == true)
            {
                if (rb1.Checked == true)
                {

                    Marks_10th = (int)Session["M10"];
                    Marks_12th = (int)Session["M12"];
                    family_income = (int)Session["Fam_Income"];
                    string G = (string)Session["Gnd"];
                  
                    if (Marks_10th >= 85 && Marks_12th >= 80 && family_income <= 150000)
                    {
                       
                        applicationstatus = "ACCEPTED";
                        remarks = "Offered with 60% scholarship under subject for approval of scholarship benifit";
                                            
                        int r = Student.UpdateAppStatus(app_uid, applicationstatus, remarks);
                        if (r > 0)
                        {
                            Response.Redirect("ProfileAdmin.aspx");
                        }
                        else
                        {
                            lbStatus.Text = "Education/Income criteria is not under subject for approval of scholarship benifit";
                            chbAgree.Checked = false;
                        }
                    }
                    else
                    {
                        lbStatus.Text = "Education/Income criteria is not under subject for approval of scholarship benifit";
                        chbAgree.Checked = false;
                    }

                  

                }
                if (rb2.Checked == true)
                {
                    Marks_10th = (int)Session["M10"];
                    Marks_12th = (int)Session["M12"];
                    family_income = (int)Session["Fam_Income"];
                    string G = (string)Session["Gnd"];

                    if (Marks_10th < 85 || Marks_12th < 80 || family_income > 150000)
                    {
                        applicationstatus = "REJECTED";
                        remarks = "Education/Income criteria is not under subject for approval of scholarship benifit";
                        int r = Student.UpdateAppStatus(app_uid, applicationstatus, remarks);
                        if (r > 0)
                        {
                            Response.Redirect("ProfileAdmin.aspx");
                        }
                        else
                        {
                            lbStatus.Text = "Education/Income criteria is not under subject for approval of scholarship benifit";
                            chbAgree.Checked = false;
                        }
                    }
                    else
                    {
                        lbStatus.Text = "Education/Income criteria is under subject for approval of scholarship benifit, the applicant can not be rejected !";
                        chbAgree.Checked = false;
                    }
                    
                }
            }
            
        }
    }
}