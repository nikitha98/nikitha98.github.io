﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class EditPersonal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string userid = (string)Session["USERID"];
                lbUserid1.Text = "Welcome " + userid + "|| Accessed Time : " + DateTime.Now;
                SqlDataReader sdr = UserTask.GetPersonalDetails(userid);
                if (sdr.Read())
                {
                    txtUserId.Text = sdr[0].ToString();
                    txFName.Text = sdr[1].ToString();
                    txlName.Text = sdr[2].ToString();
                    txDOB.Text = sdr[3].ToString();
                    txAge.Text = sdr[4].ToString();

                    txCNo.Text = sdr[6].ToString();
                    txFaName.Text = sdr[7].ToString();
                    txMName.Text = sdr[8].ToString();
                    txtIncome.Text = sdr[9].ToString();

                }
            }
        }


         //if (!Page.IsPostBack)
         //   {
         //       uid = (string)Session["Userid"];
         //       txtdate.Text = DateTime.Now.ToShortDateString();
         //       lbUserid1.Text = "Welcome " + uid + "Page accessed is " + DateTime.Now;
         //       txtuser.Text = uid;
         //   }
        protected void PersonalDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PersonalDetails.aspx");
        }

      

        protected void AddressDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddressDetails.aspx");
        }

        protected void CasteDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("CasteDetails.aspx");
        }

        protected void BankDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("BankDetails.aspx");
        }

        protected void btnReset_01_Click(object sender, EventArgs e)
        {
            txtUserId.Text = "";
           
            txFName.Text = "";
            txlName.Text = "";
            txFaName.Text = "";
            txMName.Text = "";
            txDOB.Text = "";
            txCNo.Text = "";
            rb1.Checked = false;
            rb2.Checked = false;
            txAge.Text = "";
            txFName.Focus();
        }

        protected void btnSubmit_01_Click(object sender, EventArgs e)
        {
            
                string uid=txtUserId.Text;
                
                string FN=txFName.Text;
                string LN=txlName.Text;
                DateTime DOB= DateTime.Parse(txDOB.Text);
                int age=Int32.Parse(txAge.Text);
                
                string Gender="";
                if(rb1.Checked==true)
                {                
                    Gender=rb1.Text;
                }
                if(rb2.Checked==true)
                {                
                    Gender=rb2.Text;
                }
                string C_no=txCNo.Text;
                string Fa_name= txFaName.Text;
                string Mo_name=txMName.Text;
                string Income=txtIncome.Text;
                try{
                string status=UserTask.GetUserEditPersonalStatus(uid,FN,LN,DOB,age,Gender,C_no,Fa_name,Mo_name,Income);
                lbstys.Text = status;
                }
                
                catch(Exception ex)
                {
                    lbstys.Text = ex.Message;
                }
           
        
        }

        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }

        protected void PersonalDetails1_Click1(object sender, EventArgs e)
        {

        }
    }
}