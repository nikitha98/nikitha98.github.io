﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class EditCaste : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string uid = (string)Session["UserId"];
                lbUserid1.Text = "Welcome " + uid + " || Accessed Time : " + DateTime.Now;
            }
        }

        protected void btnrset_Click(object sender, EventArgs e)
        {
            txtCaste.Text = "";

            txtCaste.Focus();
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {

            string Caste = txtCaste.Text;
            byte[] uploadfile = txtUpload.FileBytes;
            string uid = (string)Session["UserId"];

            try
            {
                string status = UserTask.GetUserEditCasteStatus(uid,Caste, uploadfile);
                lbst3.Text = status;
            }

            catch (Exception ex)
            {
                lbst3.Text = ex.Message;
            }
        }

        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }

        protected void PrsnDetails_Click(object sender, EventArgs e)
        {
            Response.Redirect("PersonalDetails.aspx");
        }

        protected void EducationalDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("EducationalDetails.aspx");
        }

        protected void AddressDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddressDetails.aspx");
        }

        protected void CasteDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("CasteDetails.aspx");
        }

        protected void BankDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("BankDetails.aspx");
        }
    }
}