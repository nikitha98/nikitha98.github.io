﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class Grievance : System.Web.UI.Page
    {
        string uid = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                uid = (string)Session["Userid"];
                txtdate.Text = DateTime.Now.ToShortDateString();
                lbUserid1.Text = "Welcome " + uid + " || Accessed Time : " + DateTime.Now;
                txtuser.Text = uid;
            }
        }

        protected void Linksignout1_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }

        protected void linkHome1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Profile.aspx");
        }

        protected void GrievanceSubmit_Click(object sender, EventArgs e)
        {
            try
            {
            string Userid = txtuser.Text;
            string FirstName = txtFN1.Text;
            string LastName = txtLN1.Text;
            DateTime PostDate = DateTime.Parse(txtdate.Text);
            string Subject = txtSub.Text;
            string Details = txtDetails.Text;
            
            if(Student.InsertUserGrievance(Userid,FirstName,LastName,PostDate,Subject,Details)>=0)
            {
                lbstatus.Text="User Grievance details Posted successfully! You will update soon";  
            }
            }
            catch(Exception ex)
            {

               lbstatus.Text= ex.Message;
            }
           

        }

        
    }
}