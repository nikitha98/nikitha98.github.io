﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class EditEducation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string userid = (string)Session["USERID"];
                lbUserid1.Text = "Welcome " + userid + " || Accessed Time : " + DateTime.Now;
                SqlDataReader sdr = UserTask.GetEducationDetails(userid);
                if (sdr.Read())
                {
                    txtUserId.Text = sdr[0].ToString();
                    txtSSLC_B.Text = sdr[1].ToString();
                    txtSSLC_Sch.Text = sdr[2].ToString();
                    txtSSLC_C.Text = sdr[3].ToString();
                    txtSSLC_st.Text = sdr[4].ToString();
                    txtHSC_B.Text = sdr[5].ToString();
                    txtHSC_Sch.Text = sdr[6].ToString();
                    txtHSC_C.Text = sdr[7].ToString();
                    txtHSC_St.Text = sdr[8].ToString();
                    txtGr.Text = sdr[9].ToString();
                    txtGr_Clg.Text = sdr[10].ToString();
                    txtGr_S.Text = sdr[11].ToString();
                    txtGr_C.Text = sdr[12].ToString();
                    txtMark_10.Text = sdr[13].ToString();
                    txtMark_12.Text = sdr[14].ToString();
                }

            }
        }

        protected void btnReset2_Click(object sender, EventArgs e)
        {
            txtSSLC_B.Text = "";
            txtSSLC_C.Text = "";
            txtSSLC_Sch.Text = "";
            txtSSLC_st.Text = "";
            txtHSC_B.Text = "";
            txtHSC_C.Text = "";
            txtHSC_Sch.Text = "";
            txtHSC_St.Text = "";
            txtGr.Text = "";
            txtGr_C.Text = "";
            txtGr_Clg.Text = "";
            txtGr_S.Text = "";
            txtSSLC_B.Focus();
        }

        protected void btnsubmit2_Click(object sender, EventArgs e)
        {

            string uid = (string)Session["UserId"];
                 string SSLC_B =txtSSLC_B.Text;
                 string SSLC_Sch =txtSSLC_Sch.Text;
                string SSLC_C = txtSSLC_C.Text;
                string SSLC_st =txtSSLC_st.Text;
                string HSC_B =txtHSC_B.Text;
               string HSC_Sch =txtHSC_Sch.Text;
                string HSC_C =txtHSC_C.Text;
                string HSC_St =txtHSC_St.Text;
                string Gr =txtGr.Text;
                string Gr_Clg =txtGr_Clg.Text;
                string Gr_C =txtGr_C.Text;
                string Gr_S =txtGr_S.Text;
                
            try{

                  string status=UserTask.GetUserEditEducationStatus(uid,SSLC_B,SSLC_Sch,SSLC_C,SSLC_st,HSC_B,HSC_Sch,HSC_C,HSC_St,Gr,Gr_Clg,Gr_C,Gr_S);
                  lbstys1.Text=status;  
                }
                
                catch(Exception ex)
                {
                    lbstys1.Text=ex.Message;
                }
            
            
        }

        protected void PersonalDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PersonalDetails.aspx");
        }

        protected void EducationalDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("EducationalDetails.aspx");
        }

        protected void AddressDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddressDetails.aspx");
        }

        protected void CasteDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("CasteDetails.aspx");
        }

        protected void BankDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("BankDetails.aspx");
        }

        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }
    }
}