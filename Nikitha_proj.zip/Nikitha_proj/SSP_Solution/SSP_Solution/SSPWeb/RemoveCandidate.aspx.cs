﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;


namespace SSPWeb
{
    public partial class RemoveCandidate : System.Web.UI.Page
    {
        string uid = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            uid=(string)Session["Userid"];
            lbWelcome.Text = "Welcome " + uid + ", Page Accessed Time :" + DateTime.Now;
        }


      

        protected void linkHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("ProfileAdmin.aspx");
            
        }

        protected void Profile_out_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }

        protected void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                if (txUserId.Text != String.Empty)
                {
                    if (AdminTask.Remove_userDetails(txUserId.Text) > 0)
                    {
                        lbStatus.Text = "User and it's all information deleted successfully";
                    }
                }
                else
                {
                    lbStatus.Text = "Input valid user_id";
                }
            }
            catch (Exception ex)
            {
                lbStatus.Text = ex.Message;
            }
        }

       
    }
}