﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class EditBank : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string userid = (string)Session["USERID"];
                lbUserid1.Text = "Welcome " + userid + " || Accessed Time : " + DateTime.Now;
                SqlDataReader sdr = UserTask.GetBankDetails(userid);
                if (sdr.Read())
                {
                    txtAcc_Num.Text = sdr[1].ToString();
                    txt_Bk.Text = sdr[2].ToString();
                    txt_Ifsc.Text = sdr[3].ToString();
                    txt_City.Text = sdr[4].ToString();

                }

            }
        }

        protected void btnrset_Click(object sender, EventArgs e)
        {
            txtAcc_Num.Text = "";
            txt_Bk.Text = "";
            txt_City.Text = "";
            txt_Ifsc.Text = "";
            txtAcc_Num.Focus();
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
                    string Acc_Num =  txtAcc_Num.Text;
                    string Bk = txt_Bk.Text;
                    string Ifsc = txt_Ifsc.Text;
                    string City = txt_City.Text;    
                    string uid = (string)Session["UserId"];
             

                try{
                string status=UserTask.GetUserEditBankStatus(uid,Acc_Num,Bk,Ifsc,City);
              lbst4.Text=status;  
                }
                
                catch(Exception ex)
                {
                    lbst4.Text=ex.Message;
                }
            }

        protected void PersonalDetails1_Click(object sender, EventArgs e)
        {
         Response.Redirect("PersonalDetails.aspx");
        }

        protected void EducationalDetails1_Click(object sender, EventArgs e)
        {
        Response.Redirect("EducationalDetails.aspx");
        }

        protected void BankDetails1_Click(object sender, EventArgs e)
        {
        Response.Redirect("BankDetails.aspx");
        }

        protected void AddressDetails1_Click(object sender, EventArgs e)
        {
        Response.Redirect("AddressDetails.aspx");
        }

        protected void CasteDetails1_Click(object sender, EventArgs e)
        {
        Response.Redirect("CasteDetails.aspx");
        }

        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }
        }

        
    }


