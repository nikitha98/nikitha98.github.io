﻿using System;
using System.Data;
using System.Data.SqlClient;


namespace SSPWeb
{
    public partial class ProfileAdmin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string uid = (string)Session["Userid"];
            lbWelcome.Text = "Welcome " + uid + ", Page Accessed Time :" + DateTime.Now;
        }


      

        protected void linkHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("ProfileAdmin.aspx");
            
        }

        protected void Profile_out_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }

       
    }
}