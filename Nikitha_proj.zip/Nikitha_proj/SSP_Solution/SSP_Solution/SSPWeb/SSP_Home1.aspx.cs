﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_LIB;

namespace SSPWeb
{
    public partial class SSP_Home1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void linkregister_Click(object sender, EventArgs e)
        {
            if (ddlUtype.SelectedValue.Equals("None"))
            {
                lbStatus.Text = "You must select user type";
            }
            else if (ddlUtype.SelectedValue.Equals("User"))
            {
                 lbStatus.Text = "";
                Response.Redirect("UserRegister.aspx?utype=User");
            }
            else
            {
                lbStatus.Text = "";
                Response.Redirect("UserRegister.aspx?utype=User");
            }
        }

       

        protected void ddlUtype_SelectedIndexChanged1(object sender, EventArgs e)
        {
            if (ddlUtype.SelectedIndex == 0)
            {
                lbStatus.Text = "Select User Type";
            }
            else
            {
                lbStatus.Text = "";
            }

        }

        protected void btnsbt_Click(object sender, EventArgs e)
        {
            try
            {
                string uid = txtuserid.Text;
                string psw = txtpsw.Text;
                string utype = ddlUtype.SelectedValue;
                if (ddlUtype.SelectedValue.Equals("None"))
                {
                    lbStatus.Text = "You must select user type";
                }
                else if (utype.Equals("User"))
                {
                    lbStatus.Text = UserTask.VerifyUserLoginStatus(uid, psw,utype);
                }
                else if (utype.Equals("Admin")) 
                {
                    lbStatus.Text = UserTask.VerifyUserLoginStatus(uid, psw,"A");
                }

                if (lbStatus.Text.Equals("Valid"))
                {
                    Session.Add("Userid", uid);
                    if (utype.Equals("User"))
                    {
                        Response.Redirect("Profile.aspx");
                    }
                    if (utype.Equals("Admin"))
                    {
                        Response.Redirect("ProfileAdmin.aspx");
                    }
                }
                else
                    lbStatus.Text = "Please enter correct UserId and Password";
            }
            catch (Exception ex)
            {
                lbStatus.Text = ex.Message;
            }

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtuserid.Text = "";
            txtpsw.Text = "";
            ddlUtype.SelectedIndex = 0;
        }
    }
}