﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class EditAddress : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string userid = (string)Session["USERID"];
                lbUserid1.Text = "Welcome " + userid + " || Accessed Time : " + DateTime.Now;
                SqlDataReader sdr = UserTask.GetAddressDetails(userid);
                if (sdr.Read())
                {

                    txtStr.Text = sdr[1].ToString();
                    txtloc.Text = sdr[2].ToString();
                    txtcity.Text = sdr[3].ToString();
                    txtstate.Text = sdr[4].ToString();
                    txtzip.Text = sdr[5].ToString();
                   

                }
            }
        }

        protected void btnReset3_Click(object sender, EventArgs e)
        {
            txtStr.Text = "";
            txtstate.Text = "";
            txtloc.Text = "";
            txtcity.Text = "";
            txtzip.Text = "";
            txtStr.Focus();
        }

        protected void btnSubmit3_Click(object sender, EventArgs e)
        {
            string Street = txtStr.Text;
            string AddressState = txtstate.Text;
            string Location = txtloc.Text;
            string city = txtcity.Text;
            string ZipCode = txtzip.Text;
            string uid = (string)Session["UserId"];
            try
            {
                string status = UserTask.GetUserEditAddressStatus(uid ,Street , Location ,city, AddressState ,ZipCode);
                lbst2.Text = status; 
            }

            catch (Exception ex)
            {
                lbst2.Text = ex.Message;
            }
        }

        protected void AddressDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("EducationalDetails.aspx");
        }

        protected void PersonalDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PersonalDetails.aspx");
        }

        protected void EducationalDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("EducationalDetails.aspx");
        }

        protected void CasteDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("CasteDetails.aspx");
        }

        protected void BankDetails1_Click(object sender, EventArgs e)
        {
            Response.Redirect("BankDetails.aspx");
        }

        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }
    }
}