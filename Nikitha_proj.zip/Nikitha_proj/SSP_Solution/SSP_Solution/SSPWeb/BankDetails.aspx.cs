﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class BankDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string userid = (string)Session["USERID"];
                lbWelcome4.Text = "Welcome " + userid + " || Accessed Time : " + DateTime.Now;

                SqlDataReader sdr = UserTask.GetBankDetails(userid);
                if (sdr.Read())
                {
                    lbUserId.Text = sdr[0].ToString();
                    lbAccount.Text = sdr[1].ToString();
                    lbBank.Text = sdr[2].ToString();
                    lbIFSC.Text = sdr[3].ToString();
                    lbBankCity.Text = sdr[4].ToString();
                    

                }
            }
        }

      

        protected void BankEdit_Click(object sender, EventArgs e)
        {
            Response.Redirect("EditBank.aspx");
        }

        protected void LikSignOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("Userid");
        }
    }
}