﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Business_LIB;

namespace SSPWeb
{
    public partial class UserRegister : System.Web.UI.Page
    {
        string utype = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            string utype = Request.QueryString["utype"];
            Session.Add("UTYPE", utype);
            lbWelcome.Text = "Welcome "+utype;
            
            lbUserid.Text = "Page access time :" + DateTime.Now;
        }

    

       
        protected void btnSubmit1_Click(object sender, EventArgs e)
        {
            if (chbAgree.Checked == true)
            {
                string uid=txtUserId.Text;
                string password=txtPsw.Text;
                string FN=txFName.Text;
                string LN=txlName.Text;
                DateTime DOB= DateTime.Parse(txDOB.Text);
                int age=Int32.Parse(txAge.Text);
                
                string Gender="";
                if(rb1.Checked==true)
                {                
                    Gender=rb1.Text;
                }
                if(rb2.Checked==true)
                {                
                    Gender=rb2.Text;
                }
                string Fa_name = txFaName.Text;
                string Mo_name = txMName.Text;
                string Income = txtIncome.Text;
                string SSLC_B = txtSSLC_B.Text;
                string SSLC_Sch = txtSSLC_Sch.Text;
                string SSLC_C = txtSSLC_C.Text;
                string SSLC_st = txtSSLC_st.Text;
                string HSC_B = txtHSC_B.Text;
                string HSC_Sch = txtHSC_Sch.Text;
                string HSC_C = txtHSC_C.Text;
                string HSC_St = txtHSC_St.Text;
                string Gr = txtGr.Text;
                string Gr_Clg = txtGr_Clg.Text;
                string Gr_C = txtGr_C.Text;
                string Gr_S = txtGr_S.Text;

                string Str = txtStr.Text;
                string state = txtstate.Text;
                string loc = txtloc.Text;
                string city = txtcity.Text;
                string zip = txtzip.Text;

                string Caste = txtCaste.Text;
                byte[] uploadfile = txtUpload.FileBytes;
                string Acc_Num = txtAcc_Num.Text;
                string Bk = txt_Bk.Text;
                string Ifsc = txt_Ifsc.Text;
                string City = txt_City.Text;
                utype = (string)Session["UTYPE"];
                utype = utype.Substring(0, 1);
                int m10 = Int32.Parse(txM10.Text);
                int m12 = Int32.Parse(txm12.Text);
                string C_no=txCNo.Text;
                if (UserTask.ValidatePhoneNo(C_no))
                {
                    lbStatus.Text = "Invalid Contact No";
                    txCNo.Focus();
                }
                else
                {
                    try
                    {
                        string status = UserTask.GetUserRegistrationStatus(uid, password, utype, FN, LN, DOB, age, Gender, C_no, Fa_name, Mo_name, Income, SSLC_B, SSLC_Sch, SSLC_C, SSLC_st, HSC_B, HSC_Sch, HSC_C, HSC_St, Gr, Gr_Clg, Gr_C, Gr_S, Str, state, loc, city, zip, Caste, uploadfile, Acc_Num, Bk, Ifsc, City, m10, m12);
                        lbStatus.Text = status;
                    }

                    catch (Exception ex)
                    {
                        lbStatus.Text = ex.Message;
                    }
                }
                
               
            }
            else
            {
                lbStatus.Text = "Enable I Agree Check Button before Submit Details !";
            }
        
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
           txtUserId.Text="";
           txtPsw.Text = "";
            txFName.Text = "";
            txlName.Text = "";
            txFaName.Text = "";
            txMName.Text = "";
            txDOB.Text = "";
            txCNo.Text = "";
            rb1.Checked = false;
            rb2.Checked = false;
            txAge.Text = "";
            txFName.Focus();
        }
        protected void btnReset2_Click(object sender, EventArgs e)
        {
           txtSSLC_B.Text = "";
           txtSSLC_C.Text = "";
           txtSSLC_Sch.Text = "";
           txtSSLC_st.Text = "";
           txtHSC_B.Text = "";
           txtHSC_C.Text = "";
           txtHSC_Sch.Text = "";
           txtHSC_St.Text = "";
           txtGr.Text = "";
           txtGr_C.Text = "";
           txtGr_Clg.Text = "";
           txtGr_S.Text = "";
           txtSSLC_B.Focus();
        }

        protected void btnReset3_Click(object sender, EventArgs e)
        {
            txtStr.Text = "";
            txtstate.Text = "";
            txtloc.Text = "";
             txtcity.Text = "";
             txtzip.Text = "";
            txtStr.Focus();
        }

        protected void btnReset4_Click(object sender, EventArgs e)
        {
            txtCaste.Text = "";
            
            txtCaste.Focus();
        }

        protected void btnReset5_Click(object sender, EventArgs e)
        {
            txtAcc_Num.Text = "";
            txt_Bk.Text = "";
            txt_City.Text = "";
            txt_Ifsc.Text = "";
            txtAcc_Num.Focus();
        }

        protected void LinkHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
         
        }
    }
}