﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Business_LIB;

namespace SSPWeb
{
    public partial class CheckUserGrievance : System.Web.UI.Page
    {
       
        string uid = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            uid= (string)Session["Userid"];
            lbWelcome.Text = "Welcome " + uid + ", Page Accessed Time :" + DateTime.Now;
            if (!Page.IsPostBack)
            {
                btnSend.Enabled=false;
                panel1.Visible = true;
                panel2.Visible = false;
                SqlDataReader sdr = AdminTask.GetRejectedUserIdNames();
                while (sdr.Read())
                {
                    String ddlItem = sdr[0] + "-" + sdr[1] + "_" + sdr[2];
                    ddlStudentList.Items.Add(ddlItem);
                }
                sdr.Close();
                ddlStudentList.SelectedIndex = 0;
            }
        }

        protected void Profile_out_Click(object sender, EventArgs e)
        {
            Response.Redirect("SSP_Home1.aspx");
            Session.Remove("USERID");
        }

        protected void linkHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("ProfileAdmin.aspx");
        }

        protected void ddlStudentList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStudentList.SelectedIndex == 0)
            {
                panel2.Visible = false;
            }
            else
            {
                panel2.Visible = true;
                string userid = ddlStudentList.SelectedValue.Substring(0, ddlStudentList.SelectedValue.IndexOf("-"));
                Session.Add("App_User", userid);
                SqlDataReader sdr=AdminTask.GetUserGrievance(userid);
               if(sdr.Read())
               {
                   txUserId.Text = sdr[0].ToString();
                   txFirstName.Text = sdr[1].ToString();
                   txLastName.Text = sdr[2].ToString();
                   txPostDate.Text = sdr[3].ToString();
                   txSubject.Text = sdr[4].ToString();
                   txDetails.Text = sdr[5].ToString();
               }
                sdr.Close();
            }
        }

       
        protected void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                string userid = (string)Session["App_User"];
                string ReplyId = (string)Session["Userid"];
                string ReplyMsg = txReply.Text;
                if (AdminTask.EditUserGrievance(userid, ReplyId, ReplyMsg) > 0)
                {
                    string applicationstatus="";
                    string remarks="";
                    lbst4.Text = "Grievance response updated!";
                    if (txReply.Text.EndsWith("20%_Scholarship"))
                    {
                         applicationstatus= "ACCEPTED";
                         remarks= txReply.Text;
                    }
                    else if (txReply.Text.EndsWith("25%_Scholarship"))
                    {
                        applicationstatus = "ACCEPTED";
                        remarks = txReply.Text;
                    }
                    else if (txReply.Text.EndsWith("Strictly_Rejected"))
                    {
                        applicationstatus = "STRICTLY REJECTED";
                        remarks = txReply.Text;
                    }
                    int r = Student.UpdateAppStatus(userid, applicationstatus, remarks);
                    if (r > 0)
                    {
                        chkReply.Checked = false;
                        Response.Redirect("ProfileAdmin.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                chkReply.Checked = false;
                lbst4.Text = ex.Message;
            }
           
        }

        protected void chkReply_CheckedChanged(object sender, EventArgs e)
        {
            if (chkReply.Checked == true)
            {
                 string userid = (string)Session["App_User"];
                txReply.ReadOnly = true;
                int income = 0,M10=0,M12=0;
                SqlDataReader sdrID = Student.GetPersonalDetailsonGrievance(userid);
                if (sdrID.Read())
                {
                    income = Int32.Parse(sdrID[0].ToString());
                    
                }
                sdrID.Close();
                SqlDataReader sdrED = Student.GetEducationDetailsonGrievance(userid);
                if (sdrED.Read())
                {
                    M10 = Int32.Parse(sdrED[0].ToString());
                   M12 = Int32.Parse(sdrED[1].ToString());
                    
                }
                sdrED.Close();
                Session.Add("INCOME", income);
                Session.Add("MARKS_10", M10);
                Session.Add("MARKS_12", M12);
                if (income > 150000 && M10 > 85 && M12 > 80)
                {
                    txReply.Text = "Considering your grievance and mapping Education/Income,You are offered with 20%_Scholarship";
                }
                else if (income < 150000 && M10 > 70 && M12 > 60)
                {
                    txReply.Text = "Considering your grievance and mapping Education/Income,You are offered with 25%_Scholarship";
                }
                else
                {
                    txReply.Text = "Education/Income criteria is not under subject for scholarship, your grievance is Strictly_Rejected";
                }
                btnSend.Enabled = true;
            }
            else
            {
                txReply.Text = "";
                txReply.ReadOnly = true;
                btnSend.Enabled = false;
            }
        }

       
        
            
        }
    }
