﻿using System;
using System.Data;
using System.Data.SqlClient;
using SSP_LIB;

namespace Business_LIB
{
    public class Student
    {
        public static SqlDataReader GetUserIdNames(String UserId)
        {
            return Applicant.GetUserIdNames(DBConnector.GetDBConnection(), UserId);
        }

        public static DataSet GetPersonalDetails(String userid)
        {
            return Applicant.GetPersonalDetails(DBConnector.GetDBConnection(), userid);
          
        }
        public static DataSet GetEducationDetails(String userid)
        {
            return Applicant.GetEducationDetails(DBConnector.GetDBConnection(), userid);
        }

        public static DataSet GetAddressDetails(String userid)
        {
            return Applicant.GetAddressDetails(DBConnector.GetDBConnection(), userid);
        }
        public static DataSet GetBankDetails(String userid)
        {
            return Applicant.GetBankDetails(DBConnector.GetDBConnection(), userid);
        }
        public static SqlDataReader GetAllCasteDetails(string userid)
        {
            return Applicant.GetCasteDetails(DBConnector.GetDBConnection(), userid);
        }
        public static int UpdateAppStatus(string uid, string appstatus, string remarks)
        {
            return Applicant.UpdateApplicationStatus(DBConnector.GetDBConnection(), uid, appstatus, remarks);
        }

        public static int InsertUserGrievance(string uid, string First_Name, string Last_Name, DateTime PostDate, string Grievance_Subject, string Grievance_Description)
        {
            return SSP_LIB.UserGrievance.InsertUserGrievance(DBConnector.GetDBConnection(), uid, First_Name, Last_Name, PostDate, Grievance_Subject, Grievance_Description);
        }

        public static SqlDataReader GetPersonalDetailsonGrievance(String userid)
        {

            return Applicant.GetPersonalDetailsonGrievance(DBConnector.GetDBConnection(), userid);

        }
        public static SqlDataReader GetEducationDetailsonGrievance(String userid)
        {

            return Applicant.GetEducationDetailsonGrievance(DBConnector.GetDBConnection(), userid);

        }
    }
}
