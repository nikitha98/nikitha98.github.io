﻿using System;
using System.Data;
using System.Data.SqlClient;
using SSP_LIB;
using System.Text.RegularExpressions;

namespace Business_LIB
{
    public class UserTask
    {
        public static string VerifyUserLoginStatus(string userid, string psw,string utype)
        {
            string status = "";
            try
            {
                SqlConnection con = DBConnector.GetDBConnection();
                status=DBConnector.ValidateUserLogin(con, userid, psw,utype);
            }
            catch (Exception ex)
            {
                status = ex.Message;
            }
            return status;
        }

        public static bool ValidatePhoneNo(string Contact_no)
        {
            bool b=false;
            String pattern = @"[0-9]{10}";
            if (Contact_no.Length == 10)
            {
                if ((new Regex(pattern)).IsMatch(Contact_no))
                   b=true;
                else
                   b=false;
            }
            return b;
        }

        public static string GetUserRegistrationStatus(string uid, string password,string utype, string First_Name, string Last_Name, DateTime Date_Of_Birth, int Age, string Gender, string Contact_no, string Father_Name, string Mother_Name, string Income_Details,
            string SSLCBoard, string SSLCSchool, string SSLCCity, string SSLCState, string HSCBoard, string HSCSchool, string HSCCity, string HSCState, string Graduation, string GraduationCollege, string GraduationCity, string GraduationState,
            string Street, string Locality, string City, string AddressState, string ZipCode, string Caste, byte[] uploadfile, string AccountNo, string BankName, string IFSCCode, String BankCity, int m10, int m12)
        {
            string message = "";
            try
            {
                SqlConnection con = DBConnector.GetDBConnection();
                int r = UserRegister.RegisterUserInfo(con, uid, password, utype,First_Name, Last_Name, Date_Of_Birth, Age, Gender, Contact_no, Father_Name, Mother_Name, Income_Details, SSLCBoard, SSLCSchool, SSLCCity, SSLCState, HSCBoard, HSCSchool, HSCCity, HSCState, Graduation, GraduationCollege, GraduationCity, GraduationState, Street, Locality, City, AddressState, ZipCode, Caste, uploadfile, AccountNo, BankName, IFSCCode, BankCity, m10, m12);
                if (r > 0)
                {
                    message = "User Registration Successful";
                }
                else
                {
                    message = "User Registration Failure";
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;

            }
            return message;
        }

        public static SqlDataReader GetPersonalDetails(string uid)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            SqlDataReader sdr = UserRegister.GetAllPersonalDetails(con, uid);
            return sdr;
        }

        public static SqlDataReader GetEducationDetails(string uid)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            SqlDataReader sdr = UserRegister.GetAllEducationDetails(con, uid);
            return sdr;
        }
        public static SqlDataReader GetAddressDetails(string uid)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            SqlDataReader sdr = UserRegister.GetAllAddressDetails(con, uid);
            return sdr;
        }
        public static SqlDataReader GetCasteDetails(string uid)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            SqlDataReader sdr = UserRegister.GetAllCasteDetails(con, uid);
            return sdr;
        }
        public static SqlDataReader GetBankDetails(string uid)
        {
            SqlConnection con = DBConnector.GetDBConnection();
            SqlDataReader sdr = UserRegister.GetAllBankDetails(con, uid);
            return sdr;
        }

       


        public static string GetUserEditPersonalStatus(string uid, string First_Name, string Last_Name, DateTime Date_Of_Birth, int Age, string Gender, string Contact_no, string Father_Name, string Mother_Name, string Income_Details)
        {
            string message = "";
            try
            {
                SqlConnection con = DBConnector.GetDBConnection();
                int r = UserRegister.EditPersonalStatus(con, uid, First_Name, Last_Name, Date_Of_Birth, Age, Gender, Contact_no, Father_Name, Mother_Name, Income_Details);
                if (r > 0)
                {
                    message = "Personal Details Editing is Successfully";
                }
                else
                {
                    message = "Personal Details Editing is Failure";
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;

            }
            return message;
        }



      


        public static string GetUserEditEducationStatus(string uid, string SSLCBoard, string SSLCSchool, string SSLCCity, string SSLCState, string HSCBoard, string HSCSchool, string HSCCity, string HSCState, string Graduation, string GraduationCollege, string GraduationCity, string GraduationState)
        {
            string message = "";
            try
            {
                SqlConnection con = DBConnector.GetDBConnection();
                int r = UserRegister.EditEducationStatus(con, uid, SSLCBoard, SSLCSchool, SSLCCity, SSLCState, HSCBoard, HSCSchool, HSCCity, HSCState, Graduation, GraduationCollege, GraduationCity, GraduationState);
                if (r > 0)
                {
                    message = "Education Details Editing is Successfully";
                }
                else
                {
                    message = "Education Details Editing is Failure";
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;

            }
            return message;
        }



        public static string GetUserEditAddressStatus(string uid, string Street, string Locality, string City, string AddressState, string ZipCode)
        {
            string message = "";
            try
            {
                SqlConnection con = DBConnector.GetDBConnection();
                int r = UserRegister.EditAddressDetails(con,uid , Street , Locality , City ,AddressState , ZipCode) ;
                if (r > 0)
                {
                    message = "Address Details Editing is Successfully";
                }
                else
                {
                    message = "Address Details Editing is Failure";
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;

            }
            return message;
        }


        public static string GetUserEditCasteStatus(string uid, string Caste, byte[] uploadfile)
        {
            string message = "";
            try
            {
                SqlConnection con = DBConnector.GetDBConnection();
                int r = UserRegister.EditCasteStatus(con, uid, Caste, uploadfile);
                if (r > 0)
                {
                    message = "Caste Details Editing is Successfully";
                }
                else
                {
                    message = "Caste Details Editing is Failure";
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;

            }
            return message;
        }

        public static string GetUserEditBankStatus(string uid, string AccountNo, string BankName, string IFSCCode, String BankCity)
        {
            string message = "";
            try
            {
                SqlConnection con = DBConnector.GetDBConnection();
                int r = UserRegister.EditBankStatus(con, uid, AccountNo, BankName, IFSCCode, BankCity);
                if (r > 0)
                {
                    message = "Bank Details Editing is Successfully";
                }
                else
                {
                    message = "Bank Details Editing is Failure";
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;

            }
            return message;
        }
    }
}
