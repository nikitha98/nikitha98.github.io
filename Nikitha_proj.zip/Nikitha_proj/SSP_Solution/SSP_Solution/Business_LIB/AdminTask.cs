﻿using System;
using System.Data;
using System.Data.SqlClient;
using SSP_LIB;

namespace Business_LIB
{
    public class AdminTask
    {
        public static SqlDataReader GetUserIdNames()
        {
            return Applicant.GetUserIdNames(DBConnector.GetDBConnection());
        }
        public static SqlDataReader GetAllRejectedUserIdNames()
        {
            return Applicant.GetAllRejectedUserIdNames(DBConnector.GetDBConnection());
        }
        public static SqlDataReader GetRejectedUserIdNames()
        {
            return Applicant.GetRejectedUserIdNames(DBConnector.GetDBConnection());
        }
        public static SqlDataReader GetShortListUserIdNames()
        {
            return Applicant.GetShortListUserIdNames(DBConnector.GetDBConnection());
        }

     

        public static SqlDataReader GetUserGrievance(string uid)
        {
            return SSP_LIB.UserGrievance.GetUserGrievance(DBConnector.GetDBConnection(),uid);
        }

        public static int EditUserGrievance(string uid, string ReplyingAdminId, string ReplyingMessage)
        {
            return SSP_LIB.UserGrievance.EditUserGrievance(DBConnector.GetDBConnection(), uid, ReplyingAdminId, ReplyingMessage);
        }
        public static int Remove_userDetails(string uid)
        {
            return SSP_LIB.UserGrievance.Remove_userDetails(DBConnector.GetDBConnection(), uid);
        }
    }
}
