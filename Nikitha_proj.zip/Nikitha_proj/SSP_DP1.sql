create database SSP_DB1



create table Login_Page
(
UserID varchar(50) primary key not null,
UserPassword varchar(15) not null, 
UserType char(1) not null
)

----------------------------------------------------------------------------------------------

alter Procedure Insert_Login_Page @UserID varchar(15),@Password varchar(15), @utype char(1)
As 
Begin
Insert into Login_Page values (@UserID,@Password,@utype)
End

------------------------------------------------------------------------------------------------

Alter procedure Remove_Login_Page @UserId varchar(50)
 As
 Begin
 Declare @recstatus int
 set @recstatus=0

 if exists(Select * from Login_Page where UserId=@userId)
 begin
 delete from  Login_Page where UserId=@userId
 set @recstatus=1
 end

 else 
 set @recstatus=0

 select @recstatus
 end
 ------------------------------------------------------------------------------------------------

 create procedure Find_Login_Page @UserId varchar(50)
 As 
 Begin
 Select * from  Login_Page where UserId=@userId
 End

 ------------------------------------------------------------------------------------------------

alter procedure Edit_Login_Page  @UserId varchar(50),@Password varchar(50),@utype char(1)
As
Begin
Update  Login_Page 
set UserId=@userId, UserPassword=@Password ,Usertype=@utype
where UserId=@userId
end
------------------------------------------------------------------------------------------------
alter Procedure Insert_Login_Page @UserID varchar(15),@Password varchar(15),@utype char(1)
As 
Begin
Insert into Login_Page values (@UserID,@Password,@utype)
End

exec dbo.Remove_Login_Page 'ram'
 
 ------------------------------------------------------------------------------------------------


/*
SNo. Mandatory Condition
1 Caste Detail be completed and authenticated
2 Education detail are Completed
3 Address Detail are completed
4 Bank Detail are provide correctly

S No. Mandatory Condition
1 Income should be <=150000 yearly
2 >85 in 10th
3 >80 in 12th
4 60% girls and 40% boys*/

create table mandatory_Condition1
(
SNO int not null,
Condition1 varchar(100) not null,
constraint pk_cond1 primary key(SNO,Condition1)
)

create Procedure Insert_mandatory_Condition1 @SNO int ,@Condition1 varchar(100) 
As 
Begin
Insert into mandatory_Condition1 values ( @SNO,@Condition1)
End

create table mandatory_Condition2
(
SNO int not null,
Condition2 varchar(100) not null,
constraint pk_cond2 primary key(SNO,Condition2)
)

create Procedure Insert_mandatory_Condition2 @SNO int ,@Condition2 varchar(100) 
As 
Begin
Insert into mandatory_Condition2 values ( @SNO,@Condition2)
End

/*
Field Name Field Type Data Type Mandatory Possible Values
First Name Text(50) Alphabetic Yes
Last Name Text(50) Alphabetic Yes
Age Drop Down NA Yes 18-120
Gender Drop Down NA Male, Female
Contact Number Text(10) Numeric No
Father Name Test(50) Alphabetic Yes 
Mother Name Test(50) AlphabeticYes
Income Detail Text(50) Numeric Yes*/

Create Table Personal_details
(
UserId varchar(50) primary key not null,

First_Name varchar(50) not null,
Last_Name varchar(50) not null,
Date_Of_Birth datetime not null,
Age int not null,
Gender char(6) not null,
Contact_no char(10) not null,
Father_Name varchar(50) not null,
Mothers_Name varchar(50) not null,
Income_Details varchar(50) not null,
)

select * from Personal_Details
select * from Education_Details

Update Personal_details
set ApplicationStatus='APPLIED', Remarks=''
where UserId='ram'

alter table Personal_Details
Add ApplicationStatus varchar(20)

alter table Personal_Details
Add Remarks varchar(100)

create procedure UPDATEAPPLICATIONSTATUS  @appstatus varchar(20), @remarks varchar(100), @userid varchar(50)
as
begin
Update Personal_details set ApplicationStatus = @appstatus, Remarks = @remarks where UserId=@userid
end

------------------------------------------------------------------------------------------------
Alter Procedure Insert_Personal_details @UserId varchar(50), @First_Name varchar(50) ,@Last_Name varchar(50) ,@Date_Of_Birth datetime ,@Age int,@Gender char(6),
@Contact_no char(10),@Father_Name varchar(50),@Mothers_Name varchar(50) ,@Income_Details varchar(50),@ApplicationStatus varchar(20), @Remarks varchar(100) 
As 
Begin
Insert into Personal_details values (@UserId,@First_Name,@Last_Name,@Date_Of_Birth ,@Age ,@Gender,
@Contact_no,@Father_Name,@Mothers_Name,@Income_Details,@ApplicationStatus, @Remarks)
End

------------------------------------------------------------------------------------------------

create procedure Remove_Personal_details @UserId varchar(50), @First_Name varchar(50) ,@Last_Name varchar(50) ,@Date_Of_Birth datetime ,@Age int,@Gender char(6),
@Contact_no char(10),@Father_Name varchar(50),@Mothers_Name varchar(50) ,@Income_Details varchar(50)
AS
 Begin
 delete from  Personal_details where UserId=@userId

 end
 ------------------------------------------------------------------------------------------------

 create procedure Find_Personal_details @UserId varchar(50)
 As 
 Begin
 Select * from  Personal_details where UserId=@userId
 End

 select userid, first_name, last_name from Personal_details where userid IN (select userid from Login_Page where not usertype = 'A') and ApplicationStatus = 'APPLIED'
 ------------------------------------------------------------------------------------------------

create procedure Edit_Personal_details @UserId varchar(50), @First_Name varchar(50) ,@Last_Name varchar(50) ,@Date_Of_Birth datetime ,@Age int,@Gender char(6),
@Contact_no char(10),@Father_Name varchar(50),@Mothers_Name varchar(50) ,@Income_Details varchar(50)
As
Begin
Update  Personal_details 
set  First_Name=@First_Name,Last_Name=@Last_Name,Date_Of_Birth=@Date_Of_Birth ,Age=@Age,Gender=@Gender,
Contact_no=@Contact_no,Father_Name=@Father_Name,Mothers_Name=@Mothers_Name ,Income_Details=@Income_Details
where UserId=@userId
end
------------------------------------------------------------------------------------------------

select * from Personal_details
select userid, first_name, last_name from Personal_details where userid IN (select userid from Login_Page where not usertype = 'A') and ApplicationStatus = 'REJECTED'



/*
10th Board Text(50) Alphanumeric Yes
School Text(50) Alphabetic Yes
City Text(50) Alphabetic Yes
State Text(50) Alphanumeric Yes
12th Board Text(50) Alphanumeric Yes
School Text(50) Alphabetic Yes
City Text(50) Alphabetic Yes
State Text(50) Alphanumeric Yes
Graduation Text(50) Alphanumeric No
School Text(50) Alphabetic No
City Text(50) Alphabetic No
State Text(50) Alphanumeric No*/


create table Education_Details
(
UserId varchar(50) primary key not null,
SSLCBoard varchar(50) not null,
SSLCSchool varchar(50) not null,
SSLCCity varchar(50) not null,
SSLCState varchar(50) not null,
HSCBoard varchar(50) not null,
HSCSchool varchar(50) not null,
HSCCity varchar(50) not null,
HSCState varchar(50) not null,
Graduation varchar(50) not null,
GraduationCollege varchar(50) not null,
GraduationCity varchar(50) not null,
GraduationState varchar(50) not null,
Marks_10 int,
Marks_12 int
)

Alter table Education_Details
add Marks_10 int

Alter table Education_Details
add Marks_12 int


------------------------------------------------------------------------------------------------
Alter Procedure Insert_Education_Details @UserId varchar(50) ,@SSLCBoard varchar(50) ,@SSLCSchool varchar(50) ,@SSLCCity varchar(50),@SSLCState varchar(50),
@HSCBoard varchar(50) ,@HSCSchool varchar(50),@HSCCity varchar(50) ,@HSCState varchar(50) ,@Graduation varchar(50),@GraduationCollege varchar(50),@GraduationCity varchar(50) ,
@GraduationState varchar(50),@Marks_10 int,@Marks_12 int 
As 
Begin
Insert into Education_Details values (@UserId ,@SSLCBoard,@SSLCSchool ,@SSLCCity ,@SSLCState ,
@HSCBoard ,@HSCSchool ,@HSCCity  ,@HSCState ,@Graduation ,@GraduationCollege ,@GraduationCity ,
@GraduationState,@Marks_10, @Marks_12)
End 

update Education_Details
Set Marks_10=87,  Marks_12=87
where UserId='ram'
------------------------------------------------------------------------------------------------

create procedure Remove_Education_Details @UserId varchar(50) ,@SSLCBoard varchar(50) ,@SSLCSchool varchar(50) ,@SSLCCity varchar(50),@SSLCState varchar(50),
@HSCBoard varchar(50) ,@HSCSchool varchar(50),@HSCCity varchar(50) ,@HSCState varchar(50) ,@Graduation varchar(50),@GraduationCollege varchar(50),@GraduationCity varchar(50) ,
@GraduationState varchar(50)
AS
 Begin
 Declare @recstatus int
 set @recstatus=0

 if exists(Select * from Education_Details where UserId=@userId)
 begin
 delete from  Education_Details where UserId=@userId
 set @recstatus=1
 end

 else 
 set @recstatus=0

 select @recstatus
 end
 ------------------------------------------------------------------------------------------------

 create procedure Find_Education_Details @UserId varchar(50)
 As 
 Begin
 Select * from  Education_Details where UserId=@userId
 End

 ------------------------------------------------------------------------------------------------

create procedure Edit_Education_Details @UserId varchar(50) ,@SSLCBoard varchar(50) ,@SSLCSchool varchar(50) ,@SSLCCity varchar(50),@SSLCState varchar(50),
@HSCBoard varchar(50) ,@HSCSchool varchar(50),@HSCCity varchar(50) ,@HSCState varchar(50) ,@Graduation varchar(50),@GraduationCollege varchar(50),@GraduationCity varchar(50) ,
@GraduationState varchar(50)
As
Begin
Update  Education_Details 
set  SSLCBoard =@SSLCBoard, SSLCSchool=@SSLCSchool, SSLCCity=@SSLCCity, SSLCState=@SSLCState,
HSCBoard=@HSCBoard , HSCSchool=@HSCSchool, HSCCity=@HSCCity, HSCState=@HSCState ,Graduation=@Graduation, GraduationCollege=@GraduationCollege,GraduationCity=@GraduationCity,
GraduationState =@GraduationState 
where UserId=@userId
end
------------------------------------------------------------------------------------------------

/*
Street Text(50) Alphanumeric Yes
Locality Text(50) Alphanumeric No
City Text(50) Alphabetic Yes
State Text(50) Alphanumeric Yes
Zip Code Text(10) Numeric Yes*/

create table Address_Details
(
UserId varchar(50) primary key not null,
Street varchar(50) not null,
Locality varchar(50) not null,
City varchar(50) not null,
AddressState varchar(50) not null,
ZipCode char(10) not null,
)

------------------------------------------------------------------------------------------------
create Procedure Insert_Address_Details @UserId varchar(50) ,@Street varchar(50),@Locality varchar(50),@City varchar(50),@AddressState varchar(50),@ZipCode char(10)
As 
Begin
Insert into Address_Details values  (@UserId ,@Street ,@Locality ,@City ,@AddressState,@ZipCode) 
End 

------------------------------------------------------------------------------------------------

create procedure Remove_Address_Details @UserId varchar(50) ,@Street varchar(50),@Locality varchar(50),@City varchar(50),@AddressState varchar(50),@ZipCode char(10)
 As
 Begin
 Declare @recstatus int
 set @recstatus=0

 if exists(Select * from Address_Details where UserId=@userId)
 begin
 delete from  Address_Details where UserId=@userId
 set @recstatus=1
 end

 else 
 set @recstatus=0

 select @recstatus
 end
 ------------------------------------------------------------------------------------------------

 create procedure Find_Address_Details @UserId varchar(50)
 As 
 Begin
 Select * from  Address_Details where UserId=@userId
 End

 ------------------------------------------------------------------------------------------------

create procedure Edit_Address_Details @UserId varchar(50) ,@Street varchar(50),@Locality varchar(50),@City varchar(50),@AddressState varchar(50),@ZipCode char(10)
As
Begin
Update  Address_Details 
set  Street=@Street ,Locality=@Locality,City=@City,AddressState=@AddressState,ZipCode =@ZipCode 
where UserId=@userId
end
------------------------------------------------------------------------------------------------
/*
Caste Text(50) Alphanumeric Yes
Upload File Text(50) File/Image Yes*/

Create table Caste_Details
(
UserId varchar(50) primary key not null,
Caste varchar(30) not null,
uploadfile varbinary(max) not null,
)
------------------------------------------------------------------------------------------------
create Procedure Insert_Caste_Details @UserId varchar(50) ,@Caste varchar(30) ,@uploadfile varbinary(max)
As 
Begin
Insert into Caste_Details values  (@UserId,@Caste,@uploadfile) 
End 

------------------------------------------------------------------------------------------------

create procedure Remove_Caste_Details @UserId varchar(50) ,@Caste varchar(30) ,@uploadfile varbinary(max)
AS
 Begin
 delete from  Caste_Details where UserId=@userId

 end
 ------------------------------------------------------------------------------------------------

 create procedure Find_Caste_Details @UserId varchar(50)
 As 
 Begin
 Select * from  Caste_Details where UserId=@userId
 End

 ------------------------------------------------------------------------------------------------

create procedure Edit_Caste_Details @UserId varchar(50) ,@Caste varchar(30) ,@uploadfile varbinary(max)
As
Begin
Update Caste_Details 
set Caste = @Caste ,uploadfile =@uploadfile 
where UserId=@userId
end
------------------------------------------------------------------------------------------------

/*
Account No Text(50) Numeric Yes
Bank Name Text(50) Alphabetic Yes
IFSC Code Text(50) Alphabetic Yes
City Text(50) Alphabetic Yes*/

create table Bank_Details
(
UserId varchar(50) primary key not null,
AccountNo varchar(50) not null,
BankName varchar(50) not null,
IFSCCode varchar(50) not null,
City varchar(50) not null,
)
------------------------------------------------------------------------------------------------

create Procedure Insert_Bank_Details @UserId varchar(50),@AccountNo varchar(50) ,@BankName varchar(50) ,@IFSCCode varchar(50),@City varchar(50) 
As 
Begin
Insert into Bank_Details values  (@UserId ,@AccountNo ,@BankName ,@IFSCCode ,@City) 
End 


------------------------------------------------------------------------------------------------

create procedure Remove_Bank_Details  @UserId varchar(50),@AccountNo varchar(50) ,@BankName varchar(50) ,@IFSCCode varchar(50),@City varchar(50)
 As
 Begin
 Declare @recstatus int
 set @recstatus=0

 if exists(Select * from Bank_Details where UserId=@userId)
 begin
 delete from  Bank_Details where UserId=@userId
 set @recstatus=1
 end

 else 
 set @recstatus=0

 select @recstatus
 end
 ------------------------------------------------------------------------------------------------

 create procedure Find_Bank_Details @UserId varchar(50)
 As 
 Begin
 Select * from  Bank_Details where UserId=@userId
 End

 ------------------------------------------------------------------------------------------------

create procedure Edit_Bank_Details @UserId varchar(50),@AccountNo varchar(50) ,@BankName varchar(50) ,@IFSCCode varchar(50),@City varchar(50)
As
Begin
Update  Bank_Details 
set  AccountNo=@AccountNo, BankName=@BankName , IFSCCode=@IFSCCode, City=@City 
where UserId=@userId
end
------------------------------------------------------------------------------------------------


Alter procedure ValidateUserLogin @UserId varchar(50), @userpassword varchar(15),@utype char(1),@status varchar(10) out
as 
begin 
 declare @uid varchar(50)
 set @uid=''
 select @uid=UserId from Login_Page where UserID=@UserId and UserPassword=@userpassword and UserType=@utype
 if @uid=''
 set @status='Invalid'
 else 
 set @status='Valid'
 End

 Begin
 Declare @status varchar(10)
 Exec ValidateUserLogin 'sathesh','12345678',@status out
 select @status
 end

 insert into Login_Page values('sathesh','sathesh','A')



 select * from Login_Page
  select * from Personal_Details
   select * from Address_Details
 select * from caste_Details
  select * from bank_Details

 delete from Login_Page where UserID='sree'
 insert into Login_Page values ('sree','sree','U')

 alter table Login_Page
 set UserType='S' where UserId='sree'





 create Procedure Find_Bank_Details @UserId varchar(50),@AccountNo varchar(50) ,@BankName varchar(50) ,@IFSCCode varchar(50),@City varchar(50) 
As 
Begin
Insert into Bank_Details values  (@UserId ,@AccountNo ,@BankName ,@IFSCCode ,@City) 
End 



create table Admin
(
FirstName varchar(50) not null,
LastName varchar(50) not null,
ContactNo varchar(50) not null,
UserName varchar(50) not null,
UserPassword varchar(50) not null,
ConfirmPassword varchar(50) not null,
)

update Login_Page
set UserType='U' where USERID='arun' or USERID='kumar'

select * from Login_Page

sp_help Login_Page

delete from Address_Details

Select * from Login_Page

select userid, first_name, last_name from Personal_details where userid = (select userid from Login_Page where not usertype = 'A')

===============================================================

create table User_Grievances
(
UserId varchar(50) primary key not null,
FirstName varchar(50) not null,
LastName varchar(50) not null,
PostDate datetime default GetDate(),
Grievance_Subject varchar(100) not null,
Grievance_Description varchar(400) not null, 
Grievance_Reply varchar(400),
Reply_Details varchar(100)
)

Create Procedure Add_User_Grievances @UserId varchar(50),@FirstName varchar(50),@LastName varchar(50),@PostDate datetime,@Grievance_Subject varchar(100),@Grievance_Description varchar(400)
as
Begin
Insert into User_Grievances values(@UserId,@FirstName,@LastName,@PostDate,@Grievance_Subject,@Grievance_Description,null,null)
End
---------------------------------------------------------------------
Create Procedure CheckGrievanceDetails_ByUserId @UserId varchar(50)
as
Begin
 Select * from User_Grievances where UserId=@UserId
End
----------------------------------------------------------------------
Create Procedure ReplyGrievanceDetails_ByUserId @UserId varchar(50),@ReplyingAdminId varchar(50), @ReplyingMessage  varchar(400)  
as
Begin
	Declare @Reply_Details varchar(100)
	Set @Reply_Details='Replied By -'+@ReplyingAdminId + ' on '+ Convert(varchar,GetDate())
	Update User_Grievances
	Set Grievance_Reply= @ReplyingMessage, Reply_Details=@Reply_Details
	where UserId=@UserId
End
---------------------------------------------------

create Procedure Remove_user @userId varchar(50) 
as
begin
delete from User_Grievances where UserId=@userId
delete from Bank_Details where UserId=@userId
delete from Caste_Details where UserId=@userId
delete from Address_Details where UserId=@userId
delete from Education_Details where UserId=@userId
delete from Personal_details where UserId=@userId
delete from Login_Page where UserId=@userId
End

select * from Bank_Details

select * from Login_Page

insert into Login_Page values('AdminSathesh','SatheshAdmin','A')